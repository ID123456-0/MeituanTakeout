# 仿美团外卖Android课程设计
项目说明：基于Android Studio开发的仿美团外卖App，使用静态JSON+Tomcat作为后端。
使用方式：
1. 下载 MeiTuan_Source.zip
2. 解压压缩包
3. Android Studio 打开解压后的文件夹等待gradle同步
4. 启动Tomcat，导入JSON数据，真机/模拟器运行
