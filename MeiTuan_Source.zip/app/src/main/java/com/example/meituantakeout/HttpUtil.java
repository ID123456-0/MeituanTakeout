package com.example.meituantakeout;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Log;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

import java.io.BufferedWriter;
import java.nio.charset.StandardCharsets;
import java.io.OutputStreamWriter;



public class HttpUtil {
    private static final String TAG = "HttpUtil";

    public interface HttpCallback {
        void onSuccess(String jsonStr);
        void onFail(Exception e);
    }

    // ✅ 现在只有这个异步获取JSON方法，名字是 getJsonAsync
    public static void getJsonAsync(String urlStr, HttpCallback callback) {
        new Thread(() -> {
            HttpURLConnection conn = null;
            BufferedReader br = null;
            StringBuilder sb = new StringBuilder();
            try {
                URL url = new URL(urlStr);
                conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("GET");
                conn.setConnectTimeout(5000);
                conn.setReadTimeout(5000);
                if (conn.getResponseCode() == 200) {
                    InputStream is = conn.getInputStream();
                    br = new BufferedReader(new InputStreamReader(is));
                    String line;
                    while ((line = br.readLine()) != null) {
                        sb.append(line);
                    }
                    callback.onSuccess(sb.toString());
                } else {
                    callback.onFail(new Exception("响应码非200"));
                }
            } catch (Exception e) {
                Log.e(TAG, "getJsonAsync error: ", e);
                callback.onFail(e);
            } finally {
                try {
                    if (br != null) br.close();
                    if (conn != null) conn.disconnect();
                } catch (IOException e) {
                    Log.e(TAG, "close error: ", e);
                }
            }
        }).start();
    }

    public static Bitmap getBitmap(String urlStr) {
        HttpURLConnection conn = null;
        Bitmap bitmap = null;
        try {
            URL url = new URL(urlStr);
            conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setConnectTimeout(5000);
            conn.setReadTimeout(5000);
            if (conn.getResponseCode() == 200) {
                InputStream is = conn.getInputStream();
                bitmap = BitmapFactory.decodeStream(is);
            }
        } catch (Exception e) {
            Log.e(TAG, "getBitmap error: ", e);
        } finally {
            if (conn != null) conn.disconnect();
        }
        return bitmap;
    }

    //加到HttpUtil里面
    public static void postJsonAsync(String urlStr, String jsonBody, HttpCallback callback) {
        new Thread(() -> {
            HttpURLConnection conn = null;
            BufferedWriter bw = null;
            BufferedReader br = null;
            StringBuilder sb = new StringBuilder();
            try {
                URL url = new URL(urlStr);
                conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setConnectTimeout(5000);
                conn.setReadTimeout(5000);
                conn.setDoOutput(true);
                conn.setRequestProperty("Content-Type","application/json;charset=utf-8");

                bw = new BufferedWriter(new OutputStreamWriter(conn.getOutputStream(), StandardCharsets.UTF_8));
                bw.write(jsonBody);
                bw.flush();

                if(conn.getResponseCode() == 200){
                    InputStream is = conn.getInputStream();
                    br = new BufferedReader(new InputStreamReader(is));
                    String line;
                    while ((line = br.readLine()) != null){
                        sb.append(line);
                    }
                    callback.onSuccess(sb.toString());
                }else{
                    callback.onFail(new Exception("提交失败，响应码："+conn.getResponseCode()));
                }
            }catch (Exception e){
                Log.e(TAG,"post error",e);
                callback.onFail(e);
            }finally {
                try{
                    if(bw!=null) bw.close();
                    if(br!=null) br.close();
                    if(conn!=null) conn.disconnect();
                }catch (IOException e){
                    Log.e(TAG,"close error",e);
                }
            }
        }).start();
    }

}
