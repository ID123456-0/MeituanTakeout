package com.example.meituantakeout;

import android.content.Context;
import android.graphics.Bitmap;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class FoodAdapter extends RecyclerView.Adapter<FoodAdapter.FoodHolder> {
    private Context mContext;
    private List<Food> foodList;
    private Handler handler = new Handler(Looper.getMainLooper());
    private OnCartChangeListener cartListener;

    public interface OnCartChangeListener{
        void onCartChange();
    }
    public void setCartChangeListener(OnCartChangeListener l){
        cartListener = l;
    }

    public FoodAdapter(Context ctx, List<Food> list){
        mContext = ctx;
        foodList = list;
    }

    @NonNull
    @Override
    public FoodHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(mContext).inflate(R.layout.item_food, parent, false);
        return new FoodHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull FoodHolder holder, int position) {
        Food food = foodList.get(position);
        holder.tvName.setText(food.getFoodName());
        holder.tvDesc.setText(food.getDesc());
        holder.tvPrice.setText("¥"+food.getPrice());

        // 从CartManager读取真实购物车数量
        int realCount = 0;
        for(Food f : CartManager.getInstance().getCartList()){
            if(f.getId() == food.getId()){
                realCount = f.getCount();
                break;
            }
        }
        holder.tvCount.setText(realCount + "");

        // 数量为0，减号禁用
        if (realCount <= 0) {
            holder.btnMinus.setEnabled(false);
        } else {
            holder.btnMinus.setEnabled(true);
        }

        //加载图片（增加判空防闪退）
        new Thread(()->{
            Bitmap bmp = HttpUtil.getBitmap(food.getFoodPic());
            handler.post(()->{
                if(bmp != null){
                    holder.ivFood.setImageBitmap(bmp);
                }
            });
        }).start();

        //加号
        holder.btnAdd.setOnClickListener(v->{
            CartManager.getInstance().addFood(food);
            notifyItemChanged(position);
            if(cartListener != null) cartListener.onCartChange();
        });

        //减号
        holder.btnMinus.setOnClickListener(v->{
            CartManager.getInstance().reduceFood(food);
            notifyItemChanged(position);
            if(cartListener != null) cartListener.onCartChange();
        });
    }

    @Override
    public int getItemCount() {
        return foodList.size();
    }

    public static class FoodHolder extends RecyclerView.ViewHolder{
        ImageView ivFood;
        TextView tvName,tvDesc,tvPrice,tvCount;
        Button btnAdd,btnMinus;
        public FoodHolder(@NonNull View itemView) {
            super(itemView);
            ivFood = itemView.findViewById(R.id.iv_food);
            tvName = itemView.findViewById(R.id.tv_food_name);
            tvDesc = itemView.findViewById(R.id.tv_food_desc);
            tvPrice = itemView.findViewById(R.id.tv_food_price);
            tvCount = itemView.findViewById(R.id.tv_count);
            btnAdd = itemView.findViewById(R.id.btn_add);
            btnMinus = itemView.findViewById(R.id.btn_minus);
        }
    }
}
