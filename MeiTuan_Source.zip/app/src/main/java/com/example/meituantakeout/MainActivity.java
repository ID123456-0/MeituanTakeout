package com.example.meituantakeout;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    private Button btnShop, btnOrder;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btnShop = findViewById(R.id.btn_shop);
        btnOrder = findViewById(R.id.btn_order);

        btnShop.setOnClickListener(v->{
            startActivity(new Intent(MainActivity.this, ShopListActivity.class));
        });
        btnOrder.setOnClickListener(v->{
            startActivity(new Intent(MainActivity.this, OrderListActivity.class));
        });
    }
}
