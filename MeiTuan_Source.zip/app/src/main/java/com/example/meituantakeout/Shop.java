package com.example.meituantakeout;

import java.io.Serializable;
import java.util.List;

public class Shop implements Serializable {
    private int id;
    private String shopName;
    private int saleNum;
    private int offerPrice;
    private int distributionCost;
    private String feature;
    private String time;
    private String banner;
    private String shopPic;
    private String shopNotice;
    private List<Food> foodList;

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getShopName() { return shopName; }
    public void setShopName(String shopName) { this.shopName = shopName; }
    public int getSaleNum() { return saleNum; }
    public void setSaleNum(int saleNum) { this.saleNum = saleNum; }
    public int getOfferPrice() { return offerPrice; }
    public void setOfferPrice(int offerPrice) { this.offerPrice = offerPrice; }
    public int getDistributionCost() { return distributionCost; }
    public void setDistributionCost(int distributionCost) { this.distributionCost = distributionCost; }
    public String getFeature() { return feature; }
    public void setFeature(String feature) { this.feature = feature; }
    public String getTime() { return time; }
    public void setTime(String time) { this.time = time; }
    public String getBanner() { return banner; }
    public void setBanner(String banner) { this.banner = banner; }
    public String getShopPic() { return shopPic; }
    public void setShopPic(String shopPic) { this.shopPic = shopPic; }
    public String getShopNotice() { return shopNotice; }
    public void setShopNotice(String shopNotice) { this.shopNotice = shopNotice; }
    public List<Food> getFoodList() { return foodList; }
    public void setFoodList(List<Food> foodList) { this.foodList = foodList; }
}
