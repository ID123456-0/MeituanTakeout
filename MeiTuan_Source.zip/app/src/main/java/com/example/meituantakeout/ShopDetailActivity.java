package com.example.meituantakeout;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

public class ShopDetailActivity extends AppCompatActivity {
    private TextView tvShopName,tvNotice,tvTotalPrice;
    private RecyclerView rvFood;
    private Button btnSettle;
    private Shop currentShop;
    private List<Food> foodList;
    private FoodAdapter foodAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shop_detail);
        tvShopName = findViewById(R.id.tv_detail_shopname);
        tvNotice = findViewById(R.id.tv_notice);
        tvTotalPrice = findViewById(R.id.tv_total_price);
        rvFood = findViewById(R.id.rv_food);
        btnSettle = findViewById(R.id.btn_settle);

        currentShop = (Shop) getIntent().getSerializableExtra("shop");
        // ==========判空保护==========
        if (currentShop == null) {
            Toast.makeText(this, "店铺数据异常", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        tvShopName.setText(currentShop.getShopName());
        tvNotice.setText(currentShop.getShopNotice());

        // =====================【重点修复1：新建副本，不共用原始对象！！】=====================
        // 不要直接拿currentShop.getFoodList()，新建ArrayList拷贝，切断引用！
        foodList = new ArrayList<>(currentShop.getFoodList());
        // 重置当前页面所有菜品count为0（每次进店铺，页面展示数量清零；购物车数据存在CartManager不受影响）
    //    for(Food food : foodList){
    //        food.setCount(0);
    //    }

        //CartManager.getInstance().setCurrentShopId(currentShop.getId());
        // 进入店铺，自动判断：店铺不同就清空购物车
        CartManager.getInstance().changeShop(currentShop.getId());


        rvFood.setLayoutManager(new LinearLayoutManager(this));
        foodAdapter = new FoodAdapter(this, foodList);
        rvFood.setAdapter(foodAdapter);

        foodAdapter.setCartChangeListener(this::calcTotal);
        calcTotal();

        btnSettle.setOnClickListener(v->{
            // 菜品总价（不含配送费，用来判断起送价）
            double foodSum = CartManager.getInstance().getTotalPrice();
            if(foodSum <= 0){
                Toast.makeText(this,"请先添加菜品！",Toast.LENGTH_SHORT).show();
                return;
            }
            // 起送价判断
            if(foodSum < currentShop.getOfferPrice()){
                Toast.makeText(this,"未达到起送价¥"+currentShop.getOfferPrice(),Toast.LENGTH_SHORT).show();
                return;
            }
            Intent intent = new Intent(ShopDetailActivity.this, OrderActivity.class);
            intent.putExtra("shop",currentShop);
            intent.putExtra("shopName", currentShop.getShopName());
            startActivity(intent);
        });
    }

    // calcTotal：展示【菜品+配送费】合计
    private void calcTotal(){
        double foodSum = CartManager.getInstance().getTotalPrice();
        double totalMoney = foodSum + currentShop.getDistributionCost();
        tvTotalPrice.setText("合计：¥"+String.format("%.2f",totalMoney));

        if (foodSum <= 0) {
            btnSettle.setEnabled(false);
            btnSettle.setBackgroundColor(0xFF888888);
        } else {
            btnSettle.setEnabled(true);
            btnSettle.setBackgroundColor(0xFFFF6600);
        }
    }
}
