package com.example.meituantakeout;

import android.os.Bundle;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.widget.Toast;
import java.util.List;

public class OrderListActivity extends AppCompatActivity {
    private RecyclerView rvOrderList;
    private OrderListAdapter adapter;
    private DBHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_list);
        rvOrderList = findViewById(R.id.rv_order_list);
        rvOrderList.setLayoutManager(new LinearLayoutManager(this));
        dbHelper = new DBHelper(this);

        // ✅ 只新建一次adapter，先实例化，空列表初始化
        adapter = new OrderListAdapter(this, null);
        // ✅ 监听只绑定一次，放到onCreate，不在load里面重复绑定！
        adapter.setOnOrderDeleteListener(orderId -> {
            new AlertDialog.Builder(OrderListActivity.this)
                    .setTitle("提示")
                    .setMessage("确定删除该订单？")
                    .setPositiveButton("确定", (dialog, which) -> {
                        dbHelper.deleteOrder(orderId);
                        Toast.makeText(OrderListActivity.this, "订单已删除", Toast.LENGTH_SHORT).show();
                        loadOrderData();
                    })
                    .setNegativeButton("取消", null)
                    .show();
        });
        rvOrderList.setAdapter(adapter);

        // 第一次加载数据
        loadOrderData();
    }

    private void loadOrderData(){
        List<OrderBean> orderList = dbHelper.getAllOrder();
        // ✅ 调用adapter的setData更新数据，而不是new新adapter
        adapter.setData(orderList);
        adapter.notifyDataSetChanged();
    }
}
