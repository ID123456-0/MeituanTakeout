package com.example.meituantakeout;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class OrderListAdapter extends RecyclerView.Adapter<OrderListAdapter.OrderHolder> {
    private Context mContext;
    private List<OrderBean> orderList;

    public interface OnOrderDeleteListener{
        void onDelete(int orderId);
    }
    private OnOrderDeleteListener deleteListener;
    public void setOnOrderDeleteListener(OnOrderDeleteListener listener){
        this.deleteListener = listener;
    }

    public OrderListAdapter(Context ctx, List<OrderBean> list){
        mContext = ctx;
        orderList = list;
    }

    // ✅ 新增：外部更新数据源
    public void setData(List<OrderBean> newList){
        this.orderList = newList;
    }

    @NonNull
    @Override
    public OrderHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(mContext).inflate(R.layout.item_order, parent, false);
        return new OrderHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull OrderHolder holder, int position) {
        // 判空，防止空指针
        if(orderList == null || orderList.get(position) == null) return;
        OrderBean order = orderList.get(position);
        holder.tvShop.setText(order.getShopName());
        holder.tvTime.setText(order.getOrderTime());
        holder.tvMoney.setText("合计：¥" + order.getTotalPrice());

        holder.btnDelete.setOnClickListener(v -> {
            if(deleteListener != null){
                deleteListener.onDelete(order.getId());
            }
        });
    }

    @Override
    public int getItemCount() {
        // ✅ 空列表保护
        return orderList == null ? 0 : orderList.size();
    }

    public static class OrderHolder extends RecyclerView.ViewHolder{
        TextView tvShop, tvTime, tvMoney;
        Button btnDelete;
        public OrderHolder(@NonNull View itemView) {
            super(itemView);
            tvShop = itemView.findViewById(R.id.tv_order_shop);
            tvTime = itemView.findViewById(R.id.tv_order_time);
            tvMoney = itemView.findViewById(R.id.tv_order_price);
            btnDelete = itemView.findViewById(R.id.btn_delete_order);
        }
    }
}
