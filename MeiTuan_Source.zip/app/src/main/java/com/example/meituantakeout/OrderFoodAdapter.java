package com.example.meituantakeout;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class OrderFoodAdapter extends RecyclerView.Adapter<OrderFoodAdapter.OrderHolder> {
    private Context ctx;
    private List<Food> list;
    public OrderFoodAdapter(Context c, List<Food> data){
        ctx = c;
        list = data;
    }
    @NonNull
    @Override
    public OrderHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(ctx).inflate(R.layout.item_order_food, parent, false);
        return new OrderHolder(v);
    }
    @Override
    public void onBindViewHolder(@NonNull OrderHolder holder, int position) {
        Food f = list.get(position);
        holder.name.setText(f.getFoodName());
        holder.count.setText("x"+f.getCount());
        holder.price.setText("¥"+String.format("%.2f",f.getPrice() * f.getCount()));
    }
    @Override
    public int getItemCount() {
        return list.size();
    }
    public static class OrderHolder extends RecyclerView.ViewHolder{
        TextView name,count,price;
        public OrderHolder(@NonNull View itemView) {
            super(itemView);
            name = itemView.findViewById(R.id.tv_of_name);
            count = itemView.findViewById(R.id.tv_of_count);
            price = itemView.findViewById(R.id.tv_of_price);
        }
    }
}
