package com.example.meituantakeout;
import java.io.Serializable;

public class Food implements Serializable {
    private int foodId;
    private String foodName;
    private double price;
    private String foodPic;
    private String desc;
    // 购物车数量，默认0
    private int count = 0;

    // ==========重点修改：把getId、setId改成操作foodId==========
    public int getId() {
        return foodId;
    }
    public void setId(int id) {
        this.foodId = id;
    }

    public int getFoodId() {
        return foodId;
    }
    public void setFoodId(int foodId) {
        this.foodId = foodId;
    }
    public String getFoodName() {
        return foodName;
    }
    public void setFoodName(String foodName) {
        this.foodName = foodName;
    }
    public double getPrice() {
        return price;
    }
    public void setPrice(double price) {
        this.price = price;
    }
    public String getFoodPic() {
        return foodPic;
    }
    public void setFoodPic(String foodPic) {
        this.foodPic = foodPic;
    }
    public String getDesc() {
        return desc;
    }
    public void setDesc(String desc) {
        this.desc = desc;
    }
    public int getCount() {
        return count;
    }
    public void setCount(int count) {
        this.count = count;
    }
}
