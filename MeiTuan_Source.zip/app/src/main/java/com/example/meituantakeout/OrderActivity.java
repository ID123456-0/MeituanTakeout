package com.example.meituantakeout;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class OrderActivity extends AppCompatActivity {
    private Shop shop;
    private List<Food> cartList;
    private RecyclerView rvOrder;
    private TextView tvShopName, tvTotal;
    private TextView tvAddressInfo;  // ✅【新增】展示地址文本
    private Button btnPay;
    private Button btnAddAddress;
    private DBHelper dbHelper;
    private AddressBean selectedAddress;

    // ✅【新增】地址页面回调接收器
    private final ActivityResultLauncher<Intent> addressLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            result -> {
                if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                    selectedAddress = (AddressBean) result.getData().getSerializableExtra("addr");
                    // ✅ 刷新地址UI
                    String addrText = selectedAddress.getName() + " " + selectedAddress.getPhone()
                            + "\n" + selectedAddress.getAddress();
                    tvAddressInfo.setText(addrText);
                }
            }
    );

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_confirm);

        tvShopName = findViewById(R.id.tv_order_shopname);
        tvTotal = findViewById(R.id.tv_order_total);
        tvAddressInfo = findViewById(R.id.tv_address_info); // ✅绑定地址TextView
        rvOrder = findViewById(R.id.rv_order_food);
        btnPay = findViewById(R.id.btn_pay);
        btnAddAddress = findViewById(R.id.btn_add_address);
        dbHelper = new DBHelper(this);

        shop = (Shop) getIntent().getSerializableExtra("shop");
        String shopName = getIntent().getStringExtra("shopName");
        tvShopName.setText(shop.getShopName());

        cartList = new ArrayList<>(CartManager.getInstance().getCartList());
        rvOrder.setLayoutManager(new LinearLayoutManager(this));
        OrderFoodAdapter adapter = new OrderFoodAdapter(this, cartList);
        rvOrder.setAdapter(adapter);

        double foodSum = CartManager.getInstance().getTotalPrice();
        double allSum = foodSum + shop.getDistributionCost();
        tvTotal.setText("合计（含配送费）：¥" + String.format("%.2f", allSum));

        // ✅【修改】按钮点击：使用launcher跳转
        btnAddAddress.setOnClickListener(v -> {
            Intent intent = new Intent(OrderActivity.this, AddressActivity.class);
            addressLauncher.launch(intent);
        });

        btnPay.setOnClickListener(v -> {
            if(selectedAddress == null){
                Toast.makeText(this, "请先添加收货地址！", Toast.LENGTH_SHORT).show();
                return;
            }
            String orderTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());
            OrderBean order = new OrderBean(shop.getShopName(), (float) allSum, orderTime, cartList);
            dbHelper.addOrder(order);

            Toast.makeText(this, "支付成功！订单已提交", Toast.LENGTH_LONG).show();
            CartManager.getInstance().clearCart();

            // ==========【新增：跳转到配送页面 OrderDeliverActivity】==========
            Intent intent = new Intent(OrderActivity.this, OrderDeliverActivity.class);
            // 把订单信息传给配送页
            intent.putExtra("shopName", shop.getShopName());
            intent.putExtra("totalPrice", allSum);
            intent.putExtra("orderTime", orderTime);
            intent.putExtra("addressText", selectedAddress.getName() + " " + selectedAddress.getPhone() + "\n" + selectedAddress.getAddress());
            startActivity(intent);

            finish(); // 关闭订单确认页，不能返回结算页
        });

    }
}
