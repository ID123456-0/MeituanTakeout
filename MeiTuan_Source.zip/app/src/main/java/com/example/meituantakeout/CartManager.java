package com.example.meituantakeout;

import java.util.ArrayList;
import java.util.List;

public class CartManager {
    // 单例
    private static CartManager instance;
    private CartManager(){}
    public static CartManager getInstance(){
        if(instance == null){
            instance = new CartManager();
        }
        return instance;
    }

    // 当前店铺id（简单区分不同店铺购物车，一次只在一家店下单）
    private int currentShopId = -1; // ✅改动1：初始值设为-1（代表没有选中店铺）
    private List<Food> cartList = new ArrayList<>();

    // ✅改动2：新增切换店铺方法（核心！进入店铺时调用）
    public void changeShop(int shopId){
        // 如果新店铺id 和 当前购物车绑定的店铺id不一样 → 清空购物车
        if(currentShopId != shopId){
            cartList.clear();
            currentShopId = shopId;
        }
    }

    // 添加/修改菜品数量
    public void addFood(Food food){
        boolean has = false;
        for(Food f : cartList){
            if(f.getId() == food.getId()){
                f.setCount(f.getCount() + 1);
                has = true;
                break;
            }
        }
        if(!has){
            food.setCount(1);
            cartList.add(food);
        }
    }

    // 减少菜品数量
    public void reduceFood(Food food){
        for(int i = 0; i < cartList.size(); i++){
            Food f = cartList.get(i);
            if(f.getId() == food.getId()){
                f.setCount(f.getCount() - 1);
                if(f.getCount() <= 0){
                    cartList.remove(i);
                }
                break;
            }
        }
    }

    // 获取购物车全部商品
    public List<Food> getCartList(){
        return cartList;
    }

    // 计算菜品总价（只算菜品，配送费放到ShopDetailActivity再加）
    public double getTotalPrice(){
        double sum = 0;
        for(Food f : cartList){
            if(f.getCount() > 0){
                sum += f.getPrice() * f.getCount();
            }
        }
        return sum;
    }

    // 清空购物车（下单成功后调用）
    public void clearCart(){
        cartList.clear();
        currentShopId = -1; // ✅改动3：清空的时候同步重置店铺id
    }

    // 设置当前店铺ID（保留，备用）
    public void setCurrentShopId(int shopId){
        this.currentShopId = shopId;
    }
    public int getCurrentShopId(){
        return currentShopId;
    }
}
