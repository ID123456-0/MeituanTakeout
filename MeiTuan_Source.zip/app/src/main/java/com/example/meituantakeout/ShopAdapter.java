package com.example.meituantakeout;

import android.content.Context;
import android.graphics.Bitmap;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class ShopAdapter extends RecyclerView.Adapter<ShopAdapter.ShopHolder> {
    private Context mContext;
    private List<Shop> shopList;
    private OnShopClickListener listener;
    private Handler mHandler = new Handler(Looper.getMainLooper());

    public interface OnShopClickListener{
        void onShopClick(Shop shop);
    }
    public void setOnShopClickListener(OnShopClickListener l){
        this.listener = l;
    }

    public ShopAdapter(Context context, List<Shop> list){
        mContext = context;
        shopList = list;
    }

    @NonNull
    @Override
    public ShopHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(mContext).inflate(R.layout.item_shop, parent, false);
        return new ShopHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ShopHolder holder, int position) {
        Shop shop = shopList.get(position);
        holder.tvName.setText(shop.getShopName());
        holder.tvSale.setText("月售"+shop.getSaleNum()+"单");
        holder.tvInfo.setText("起送¥"+shop.getOfferPrice()+" | 配送费¥"+shop.getDistributionCost()+" | "+shop.getTime());
        //子线程加载图片
        new Thread(()->{
            Bitmap bmp = HttpUtil.getBitmap(shop.getShopPic());
            mHandler.post(()-> holder.ivShop.setImageBitmap(bmp));
        }).start();
        holder.itemView.setOnClickListener(v->{
            if(listener != null) listener.onShopClick(shop);
        });
    }

    @Override
    public int getItemCount() {
        return shopList.size();
    }

    public static class ShopHolder extends RecyclerView.ViewHolder{
        ImageView ivShop;
        TextView tvName,tvSale,tvInfo;
        public ShopHolder(@NonNull View itemView) {
            super(itemView);
            ivShop = itemView.findViewById(R.id.iv_shop);
            tvName = itemView.findViewById(R.id.tv_shop_name);
            tvSale = itemView.findViewById(R.id.tv_sale);
            tvInfo = itemView.findViewById(R.id.tv_price_info);
        }
    }
}
