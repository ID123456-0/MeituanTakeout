package com.example.meituantakeout;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class OrderDeliverActivity extends AppCompatActivity {
    private TextView tvShop, tvTotal, tvTime, tvAddress;
    private Button btnConfirmReceive;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_deliver);

        tvShop = findViewById(R.id.tv_deliver_shop);
        tvTotal = findViewById(R.id.tv_deliver_total);
        tvTime = findViewById(R.id.tv_deliver_time);
        tvAddress = findViewById(R.id.tv_deliver_addr);
        btnConfirmReceive = findViewById(R.id.btn_finish_receive);

        //接收从OrderActivity传过来的数据
        Intent data = getIntent();
        String shopName = data.getStringExtra("shopName");
        double total = data.getDoubleExtra("totalPrice",0);
        String time = data.getStringExtra("orderTime");
        String addr = data.getStringExtra("addressText");

        tvShop.setText("店铺：" + shopName);
        tvTotal.setText("订单金额：¥" + String.format("%.2f",total));
        tvTime.setText("下单时间：" + time);
        tvAddress.setText("收货地址：\n" + addr);

        btnConfirmReceive.setOnClickListener(v->{
            Toast.makeText(this,"确认收货成功！",Toast.LENGTH_SHORT).show();
            //确认收货后，跳订单列表页 OrderListActivity
            Intent intent = new Intent(OrderDeliverActivity.this, OrderListActivity.class);
            startActivity(intent);
            finish();
        });
    }
}
