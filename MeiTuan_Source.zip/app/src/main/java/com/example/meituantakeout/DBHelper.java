package com.example.meituantakeout;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.util.ArrayList;
import java.util.List;

public class DBHelper extends SQLiteOpenHelper {
    private static final String DB_NAME = "meituan.db";
    private static final int VERSION = 1;
    private final Gson gson = new Gson();

    public DBHelper(Context context) {
        super(context, DB_NAME, null, VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String sql = "create table tb_order (" +
                "id integer primary key autoincrement," +
                "shop_name text," +
                "total_price real," +
                "order_time text," +
                "foods text)";
        db.execSQL(sql);

        // 地址表
        String sqlAddress = "create table tb_address (" +
                "id integer primary key autoincrement," +
                "name text," +
                "phone text," +
                "address text)";
        db.execSQL(sqlAddress);

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {}

    public long addOrder(OrderBean order){
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("shop_name", order.getShopName());
        cv.put("total_price", order.getTotalPrice());
        cv.put("order_time", order.getOrderTime());
        cv.put("foods", gson.toJson(order.getFoodList()));
        long id = db.insert("tb_order", null, cv);
        db.close();
        return id;
    }

    public List<OrderBean> getAllOrder(){
        List<OrderBean> list = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.query("tb_order", null, null, null, null, null, "id desc");
        while(cursor.moveToNext()){
            OrderBean bean = new OrderBean();
            bean.setId(cursor.getInt(0));
            bean.setShopName(cursor.getString(1));
            bean.setTotalPrice(cursor.getFloat(2));
            bean.setOrderTime(cursor.getString(3));
            String json = cursor.getString(4);
            List<Food> foodList = gson.fromJson(json, new TypeToken<List<Food>>(){}.getType());
            bean.setFoodList(foodList);
            list.add(bean);
        }
        cursor.close();
        db.close();
        return list;
    }

    // 添加收货地址
    public long addAddress(AddressBean address){
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("name",address.getName());
        cv.put("phone",address.getPhone());
        cv.put("address",address.getAddress());
        long id = db.insert("tb_address",null,cv);
        db.close();
        return id;
    }
    // 查询所有地址
    public List<AddressBean> getAllAddress(){
        List<AddressBean> list = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.query("tb_address",null,null,null,null,null,null);
        while (cursor.moveToNext()){
            AddressBean bean = new AddressBean();
            bean.setId(cursor.getInt(0));
            bean.setName(cursor.getString(1));
            bean.setPhone(cursor.getString(2));
            bean.setAddress(cursor.getString(3));
            list.add(bean);
        }
        cursor.close();
        db.close();
        return list;
    }

    public void deleteOrder(int orderId){
        SQLiteDatabase db = getWritableDatabase();
        db.delete("tb_order", "id=?", new String[]{String.valueOf(orderId)});
        db.close();
    }


}
