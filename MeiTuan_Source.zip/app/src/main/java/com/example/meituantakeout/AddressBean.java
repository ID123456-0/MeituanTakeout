package com.example.meituantakeout;

import java.io.Serializable;
public class AddressBean implements Serializable {
    private int id;
    private String name;    //姓名
    private String phone;   //手机号
    private String address; //详细地址

    public AddressBean(){}
    public AddressBean(String name, String phone, String address) {
        this.name = name;
        this.phone = phone;
        this.address = address;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }
    public String getAddress() { return address; }
    public void setAddress(String address) { this.address = address; }
}
