package com.example.meituantakeout;

import java.util.List;

public class OrderBean {
    private int id;
    private String shopName;
    private float totalPrice;
    private String orderTime;
    private List<Food> foodList;

    private AddressBean address;

    public OrderBean(){}
    public OrderBean(String shopName, float totalPrice, String orderTime, List<Food> foodList) {
        this.shopName = shopName;
        this.totalPrice = totalPrice;
        this.orderTime = orderTime;
        this.foodList = foodList;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getShopName() { return shopName; }
    public void setShopName(String shopName) { this.shopName = shopName; }
    public float getTotalPrice() { return totalPrice; }
    public void setTotalPrice(float totalPrice) { this.totalPrice = totalPrice; }
    public String getOrderTime() { return orderTime; }
    public void setOrderTime(String orderTime) { this.orderTime = orderTime; }
    public List<Food> getFoodList() { return foodList; }
    public void setFoodList(List<Food> foodList) { this.foodList = foodList; }

    // getter setter
    public AddressBean getAddress() { return address; }
    public void setAddress(AddressBean address) { this.address = address; }
}
