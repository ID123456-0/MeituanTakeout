package com.example.meituantakeout;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.widget.ImageView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import java.util.List;

public class ShopListActivity extends AppCompatActivity {
    private RecyclerView rvShop;
    private ImageView ivBanner;
    private ShopAdapter adapter;
    private List<Shop> shopData;
    // ✅ 加final消除黄色警告
    private final Handler handler = new Handler(Looper.getMainLooper());
    // ✅ 模拟器访问本机固定IP：10.0.2.2
    private final String URL = "http://192.168.92.1:8080/order/shop_list_data.json";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shop_list);
        rvShop = findViewById(R.id.rv_shop);
        ivBanner = findViewById(R.id.iv_banner);
        rvShop.setLayoutManager(new LinearLayoutManager(this));
        loadShopData();
    }

    private void loadShopData(){
        // ✅ 使用新的异步getJsonAsync，不再自己new Thread包一层
        HttpUtil.getJsonAsync(URL, new HttpUtil.HttpCallback() {
            @Override
            public void onSuccess(String jsonStr) {
                Gson gson = new Gson();
                Type type = new TypeToken<List<Shop>>(){}.getType();
                shopData = gson.fromJson(jsonStr, type);

                // 切主线程刷新UI
                runOnUiThread(() -> {
                    adapter = new ShopAdapter(ShopListActivity.this, shopData);
                    rvShop.setAdapter(adapter);
                    // ✅ !shopData.isEmpty() 消除警告
                    if(shopData != null && !shopData.isEmpty()){
                        //加载第一张店铺的banner图
                        new Thread(()->{
                            Bitmap b = HttpUtil.getBitmap(shopData.get(0).getBanner());
                            handler.post(()-> ivBanner.setImageBitmap(b));
                        }).start();
                    }
                    adapter.setOnShopClickListener(shop->{
                        Intent intent = new Intent(ShopListActivity.this, ShopDetailActivity.class);
                        intent.putExtra("shop", shop);
                        startActivity(intent);
                    });
                });
            }

            @Override
            public void onFail(Exception e) {
                runOnUiThread(() -> {
                    // 网络失败，可以在这里toast提示
                });
            }
        });
    }
}
