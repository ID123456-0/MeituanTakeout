package com.example.meituantakeout;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;

public class AddressActivity extends AppCompatActivity {
    private EditText etName,etPhone,etAddr;
    private Button btnSave;
    private DBHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_address);
        etName = findViewById(R.id.et_name);
        etPhone = findViewById(R.id.et_phone);
        etAddr = findViewById(R.id.et_addr);
        btnSave = findViewById(R.id.btn_save_addr);
        dbHelper = new DBHelper(this);

        btnSave.setOnClickListener(v->{
            String name = etName.getText().toString().trim();
            String phone = etPhone.getText().toString().trim();
            String address = etAddr.getText().toString().trim();

            // ==========校验开始==========
            if(name.isEmpty()){
                Toast.makeText(AddressActivity.this, "请填写收货人姓名", Toast.LENGTH_SHORT).show();
                etName.requestFocus();
                return;
            }
            if(phone.isEmpty()){
                Toast.makeText(AddressActivity.this, "请填写手机号", Toast.LENGTH_SHORT).show();
                etPhone.requestFocus();
                return;
            }
            if(phone.length() != 11){
                Toast.makeText(AddressActivity.this, "手机号必须是11位", Toast.LENGTH_SHORT).show();
                etPhone.requestFocus();
                return;
            }
            if(address.isEmpty()){
                Toast.makeText(AddressActivity.this, "请填写详细地址", Toast.LENGTH_SHORT).show();
                etAddr.requestFocus();
                return;
            }
            // ==========校验通过，继续保存==========
            AddressBean bean = new AddressBean();
            bean.setName(name);
            bean.setPhone(phone);
            bean.setAddress(address);
            DBHelper db = new DBHelper(AddressActivity.this);
            db.addAddress(bean);
            Toast.makeText(AddressActivity.this, "地址保存成功", Toast.LENGTH_SHORT).show();
            // =====重点：打包数据返回=====
            Intent intent = new Intent();
            intent.putExtra("addr", bean);
            setResult(RESULT_OK, intent);
            finish();
        });

    }
}
